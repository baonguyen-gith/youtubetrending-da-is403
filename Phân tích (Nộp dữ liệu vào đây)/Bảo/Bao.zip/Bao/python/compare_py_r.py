# -*- coding: utf-8 -*-
"""compare_py_r.py - Đối chiếu số Python và R (tiêu chí "khớp 3 chữ số" của B4, B5).
Chạy SAU KHI đã chạy cả hai bản:   python compare_py_r.py
  Q1 : outputs/q1/q1_descriptive_table.csv  vs  outputs/q1_R/q1_descriptive_table.csv (+ by_hour, by_dow)
  Q3b: outputs/q3b/q3b_or_table.csv         vs  outputs/q3b_R/q3b_coef_M1_R.csv, q3b_coef_M2_R.csv
"""
import os, re
import numpy as np, pandas as pd
B = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "outputs")

def cmp(a, b, name, tol=5e-4):
    d = np.abs(np.asarray(a, float) - np.asarray(b, float))
    rel = d / np.maximum(np.abs(np.asarray(b, float)), 1e-12)
    ok = bool(np.all((d <= tol) | (rel <= 5e-4)))
    print(f"{'KHỚP ' if ok else 'LỆCH '} {name}: sai khác tuyệt đối lớn nhất = {np.nanmax(d):.6g}")
    return ok

def norm(t):  # đưa tên biến Python về dạng make.names của R
    t = "(Intercept)" if t == "const" else t
    return re.sub(r"[^0-9A-Za-z_.()]", ".", t)

for f in ["q1_descriptive_table.csv", "q1_by_hour.csv", "q1_by_dow.csv"]:
    p, r = os.path.join(B, "q1", f), os.path.join(B, "q1_R", f)
    if not (os.path.exists(p) and os.path.exists(r)): print("Thiếu", f); continue
    a, b = pd.read_csv(p), pd.read_csv(r)
    cols = [c for c in a.columns if c in b.columns and a[c].dtype != object and c not in ("pub_hour", "pub_dow")]
    for c in cols: cmp(a[c], b[c], f"{f}:{c}")
pm, pf = os.path.join(B, "q3b", "q3b_or_table.csv"), os.path.join(B, "q3b_R")
if os.path.exists(pm) and os.path.exists(os.path.join(pf, "q3b_coef_M1_R.csv")):
    a = pd.read_csv(pm); a["k"] = a["term"].map(norm)
    for tag, cols in [("M1", ["OR_M1", "OR_lo95_M1", "OR_hi95_M1"]), ("M2", ["OR_M2", "OR_lo95_M2", "OR_hi95_M2"])]:
        r = pd.read_csv(os.path.join(pf, f"q3b_coef_{tag}_R.csv")); r["k"] = r["term"]
        j = a.merge(r, on="k", suffixes=("_py", "_R")).dropna(subset=[cols[0]])
        cmp(j[cols[0]], j["OR"], f"Logit {tag} OR (3 chữ số thập phân)", tol=5e-4)
        cmp(j[cols[1]], j["OR_lo95"], f"Logit {tag} CI dưới (cho phép lệch <= 0,01)", tol=1e-2)
        cmp(j[cols[2]], j["OR_hi95"], f"Logit {tag} CI trên (cho phép lệch <= 0,01)", tol=1e-2)
else:
    print("Chưa có kết quả R của Q3b.")
