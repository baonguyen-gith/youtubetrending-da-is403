# Hướng dẫn dựng dashboard Power BI (việc B11 – phần của Bảo)

Tôi không tạo được file `.pbix` trong môi trường này. Các CSV đã sẵn trong `outputs/powerbi/`; bạn làm theo các bước dưới đây trong Power BI Desktop.

## 1. Nạp dữ liệu
Get data → Text/CSV, nạp: `kpi_overview.csv`, `q1_by_hour.csv`, `q1_heatmap.csv`, `q1_by_category.csv`, `q1_by_dow.csv`, `reliability_table.csv`, `q3b_or_table.csv` (và CSV của Q2b, Q5, Q6, Q4 do các bạn khác xuất ra `outputs/`). Mỗi bảng đứng riêng, không cần quan hệ.

## 2. Trang 1 – Tổng quan
- Thẻ (Card) từ `kpi_overview`: dùng bộ lọc chi_so = "n_H (quần thể phân tích)", "Số kênh trong H", "Số video từng lọt Trending", "Tỷ lệ viral_A (%)".
- Bảng `reliability_table` (cột tieu_chi, so_dem, ty_le_pct) – kiểm tra khớp Bảng 3.3 trong báo cáo.
- Biểu đồ cột `q1_by_category`: trục X = category_name, giá trị = median_lv_adj, sắp theo rank_n, lọc 10 dòng đầu.

## 3. Trang 2 – Giờ đăng và thể loại
- Đường + cột `q1_by_hour`: trục X = pub_hour; đường = median_lv_adj và median_lv_within_channel; cột = n (trục phụ).
- Heatmap: Matrix với hàng = pub_hour, cột = dow_name (sắp theo pub_dow), giá trị = median_lv_adj_masked, định dạng màu có điều kiện (phân kỳ, trung tâm 0).
- Phần Q2b của bạn khác: thêm biểu đồ theo hướng dẫn của người phụ trách.

## 4. Trang 3 – Viral
- Biểu đồ thanh ngang `q3b_or_table`: lọc loại dòng `const`, trục Y = label, giá trị = OR_M1, thang log (Format → Y axis → Log scale), thêm thanh sai số từ OR_lo95_M1 và OR_hi95_M1.
- Các biểu đồ Q5, Q6 theo CSV của người phụ trách.

## 5. Độ đo (DAX)
```
n_H = CALCULATE(MAX(kpi_overview[gia_tri]), kpi_overview[chi_so] = "n_H (quần thể phân tích)")
Ty_le_viral = CALCULATE(MAX(kpi_overview[gia_tri]), kpi_overview[chi_so] = "Tỷ lệ viral_A (%)") / 100
Chenh_gio = MAX(q1_by_hour[median_lv_adj]) - MIN(q1_by_hour[median_lv_adj])
Chenh_gio_trong_kenh = MAX(q1_by_hour[median_lv_within_channel]) - MIN(q1_by_hour[median_lv_within_channel])
```
(`gia_tri` trong kpi_overview có kiểu văn bản vì có cả ngày tháng; đổi kiểu sang số trước khi dùng MAX, hoặc lọc các dòng số.)

## 6. Yêu cầu của báo cáo
Chụp 3 ảnh trang → dán vào Phụ lục D (Hình D.1–D.3). Ghi rõ biểu đồ nào chưa làm. Đối chiếu số trên dashboard với Bảng 3.3, Bảng 5.1, Bảng 5.8.
